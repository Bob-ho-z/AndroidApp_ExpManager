package edu.cuhk.csci3310.expmanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedList;

public class RecordListAdapter extends RecyclerView.Adapter<RecordListAdapter.RecordViewHolder> implements Filterable {
    private LinkedList<Record> mRecordPathList;
    private LinkedList<Record> mRecordFullList;
    private LayoutInflater mInflator;
    private onUpdateSummary mCallback; //call back function
    private String mTypeFilePath = "android.resource://edu.cuhk.csci3310.ExpManager/drawable/";

    class RecordViewHolder extends RecyclerView.ViewHolder{
        public ImageView typeItemView;
        public ImageView removeItemView;
        public TextView nameView;
        public TextView amountView;
        public Record record;
        public TextView dateView;
        final RecordListAdapter mAdapter;
        private String log = "holder";
        private databaseHelper dbHelper;

        private final int REQUEST_UPDATE_RECORD = 2;

        public RecordViewHolder(View itemView,RecordListAdapter adapter) {
            super(itemView);
            //Log.d("afa","ddd");
            typeItemView = itemView.findViewById(R.id.recordTypeImage);
            removeItemView = itemView.findViewById(R.id.deleteButton);
            nameView = itemView.findViewById(R.id.recordName);
            amountView = itemView.findViewById(R.id.RecordAmount);
            dateView = itemView.findViewById(R.id.recordDate);
            this.mAdapter = adapter;

            //edit button
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent detailIntent = new Intent(itemView.getContext(),DetailRecordActivity.class);
                    Bundle recordBundle = new Bundle();
                    recordBundle.putString("name",record.getName());
                    recordBundle.putString("description",record.getDescription());
                    recordBundle.putString("date",record.getDate_of_record());
                    recordBundle.putInt("type",record.getCategory());
                    recordBundle.putDouble("amount",record.getAmount());
                    recordBundle.putInt("id",record.getId());
                    detailIntent.putExtras(recordBundle);
                    ((Activity) itemView.getContext()).startActivityForResult(detailIntent,REQUEST_UPDATE_RECORD);
                }
            });
            //remove button
            removeItemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder confirmMSG = new AlertDialog.Builder(itemView.getContext());
                    confirmMSG.setTitle("Delete record");
                    confirmMSG.setMessage("Are you sure to delete this record?");
                    confirmMSG.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            int id = record.getId();
                            int mPosition = getLayoutPosition();
                            mRecordPathList.remove(mPosition);
                            deleteFullList(record);
                            mAdapter.notifyDataSetChanged();

                            //all sqlite to remove the record
                            dbHelper = new databaseHelper(itemView.getContext());
                            SQLiteDatabase db = dbHelper.getWritableDatabase();
                            String sql = "DELETE FROM sampleRecord0 WHERE id = " + String.valueOf(id) + ";";
                            db.execSQL(sql);
                            Toast.makeText(itemView.getContext(),"deleted",Toast.LENGTH_SHORT).show();
                            mCallback.updateSummary();
                        }
                    });
                    confirmMSG.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //
                        }
                    });
                    confirmMSG.show();
                }
            });


        }
    }

    public RecordListAdapter(Context context, LinkedList<Record> recordItemList, onUpdateSummary ous) {
        mInflator = LayoutInflater.from(context);
        //Log.d("adapter",String.valueOf(recordItemList.size()));
        mRecordPathList = recordItemList;
        mRecordFullList = new LinkedList<>(recordItemList);
        //Log.d("adapter",String.valueOf(mRecordPathList.size()));
        mCallback = ous;
    }

    @Override
    public void onBindViewHolder(@NonNull RecordListAdapter.RecordViewHolder holder, int position) {
        //Log.d("binding",String.valueOf(position));
        holder.record = mRecordPathList.get(position);
        //Log.d("onBinding",holder.record.getName());
        holder.nameView.setText(holder.record.getName());
        holder.amountView.setText("$" + Double.toString(holder.record.getAmount()));
        holder.typeItemView.setImageResource(getPath(holder.record.getCategory()));
        holder.dateView.setText(holder.record.getDate_of_record());
    }

    private int getPath(int type) {
        int typeID = -1;
        if(type == 0)
            typeID = R.drawable.ic_type_income;
        else if(type == 1)
            typeID = R.drawable.ic_type_food;
        else if(type == 2)
            typeID = R.drawable.ic_type_tuition_fee;
        else if(type == 3)
            typeID = R.drawable.ic_type_leisure;
        else if(type == 4)
            typeID = R.drawable.ic_type_others;
        return typeID;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    public void addFullList(Record record){
        mRecordFullList.add(record);
    }

    public void updateFullList(Record record){
        int pos = 0;
        for (Record oldRecord: mRecordFullList){
            if (record.getId() == oldRecord.getId()){
                mRecordFullList.set(pos,record);
            }
            pos++;
        }

    }

    public void deleteFullList(Record record){
        int pos = 0;
        int max_pos = mRecordFullList.size();
        for (pos = 0; pos < mRecordFullList.size(); pos++){
            if (mRecordFullList.get(pos).getId() == record.getId()){
                mRecordFullList.remove(pos);
                break;
            }
        }
    }

    @NonNull
    @Override
    public RecordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Log.d("Holder","onCreateViewHolder");
        View mItemView = mInflator.inflate(R.layout.record_listitem, parent, false);
        return new RecordViewHolder(mItemView, this);
    }

    @Override
    public long getItemId(int position) {
        return super.getItemId(position);
    }

    @Override
    public int getItemCount() {
        return mRecordPathList.size();
    }

    @Override
    public Filter getFilter(){
        return ResultFilter;
    }


    private Filter ResultFilter = new Filter(){

        @Override
        protected FilterResults performFiltering(CharSequence searchKey) {
            LinkedList<Record> filteredRecord = new LinkedList<>();
            //Log.d("filter",searchKey.toString().trim());
            if (searchKey == null || searchKey.length() == 0){
                filteredRecord.addAll(mRecordFullList);
            }
            else{
                String searchField = searchKey.toString().trim();
                for (Record curRecord: mRecordFullList){
                    if (curRecord.getName().toLowerCase().contains(searchField)){
                        filteredRecord.add(curRecord);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredRecord;
            //Log.d("total",Integer.toString(((LinkedList)results.values).size()));
            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            mRecordPathList.clear();
            //Log.d("total",Integer.toString(((LinkedList)filterResults.values).size()));
            mRecordPathList.addAll((LinkedList) filterResults.values);
            notifyDataSetChanged();
        }
    };

}
