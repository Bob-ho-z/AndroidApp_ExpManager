package edu.cuhk.csci3310.expmanager;

import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class AnalyseExpenses extends AppCompatActivity {
    private PieChart pieChart;
    private databaseHelper dbHelper;
    public static final SimpleDateFormat checkMonth = new SimpleDateFormat("M");
    private  boolean notEnd = true;
    private String DBMonths;
    private int DBMonthI;
    private List<PieEntry> entries = new ArrayList<>();
    private float DietAmount=0, TutorialFeeAmount=0, LeisureAmount=0,OthersAmount=0;
    ArrayList<HashMap<String, String>> thisMonthDataArrayList = new ArrayList<>();//get this month data
    private int currentMonthI;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.analyse_expenses);
        pieChart = findViewById(R.id.pieChart_view);
        showPieChart();

    }

    private void showPieChart()
    {
        // this function for get data and output the pir chart.

        dbHelper = new databaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Date d = new Date(System.currentTimeMillis());
        String currentMonthS = checkMonth.format(d);
        try
        {
            currentMonthI = Integer.parseInt(currentMonthS);

        }
        catch (NumberFormatException e)
        {
            e.printStackTrace();
            //Log.d("debug","current date cannot prase");
        }

        Cursor c = db.query("sampleRecord0", new String[]{"id", "type", "amount","date"}, "type != 0", null, null, null, "date");
        if (c.getCount() > 0) {
            c.moveToFirst();


            while (notEnd) {
                HashMap<String, String> hashMap = new HashMap<>();

                String id = c.getString(0);
                String type = c.getString(1);
                String amount = c.getString(2);
                String date = c.getString(3);
                // Log.d("debug","Date is "+ date);

                hashMap.put("id", id);
                hashMap.put("type",type);
                hashMap.put("amount", amount);
                hashMap.put("date", date);
                try {
                    //  Log.d("debug","Date in try is "+ date);
                    DBMonths = date.substring(5,7);
                    //  Log.d("debug","DBMonths is "+ DBMonths);
                    DBMonthI = Integer.parseInt(DBMonths);
                    // Log.d("debug","dbmonth is "+ DBMonthI + "and currentMonthI is "+ currentMonthI);
                }
                catch (NumberFormatException e)
                {
                    e.printStackTrace();
                    //  Log.d("debug","db date cannot parse to int");
                }


                if(DBMonthI == currentMonthI)
                    thisMonthDataArrayList.add(hashMap);
                if(!(c.moveToNext()))
                {
                    notEnd = false;
                }

            }

            if(thisMonthDataArrayList.isEmpty())
            {
                pieChart.setNoDataText("No Records for this month");
                pieChart.setNoDataTextColor(Color.BLACK);
                return;
            }



            for(int i=0;i<thisMonthDataArrayList.size();i++)
            {
                switch(thisMonthDataArrayList.get(i).get("type").charAt(0))
                {
                    case '1':
                        DietAmount = DietAmount  + Float.parseFloat(thisMonthDataArrayList.get(i).get("amount"));
                        break;
                    case '2':
                        TutorialFeeAmount = TutorialFeeAmount  + Float.parseFloat(thisMonthDataArrayList.get(i).get("amount"));
                        break;
                    case '3':
                        LeisureAmount = LeisureAmount  + Float.parseFloat(thisMonthDataArrayList.get(i).get("amount"));
                        break;
                    case '4':
                        OthersAmount = OthersAmount  + Float.parseFloat(thisMonthDataArrayList.get(i).get("amount"));
                        break;
                }
            }

            ArrayList<Integer> colors = new ArrayList<>();
            colors.add(Color.parseColor("#304567"));
            colors.add(Color.parseColor("#309967"));
            colors.add(Color.parseColor("#476567"));
            colors.add(Color.parseColor("#890567"));

            if(DietAmount != 0)
                entries.add(new PieEntry(DietAmount,"Diet"));
            if(TutorialFeeAmount != 0)
                entries.add(new PieEntry(TutorialFeeAmount,"Tutorial Fee"));
            if(LeisureAmount != 0)
                entries.add(new PieEntry(LeisureAmount,"Leisure"));
            if(OthersAmount != 0)
                entries.add(new PieEntry(OthersAmount,"Others"));

            PieDataSet set = new PieDataSet(entries, "Expenses Analyse");
            set.setColors(colors);
            set.setValueTextSize(12f);
            PieData data = new PieData(set);
            //data.setValueFormatter(new PercentFormatter());

            pieChart.setData(data);
            pieChart.invalidate(); // refresh



        }
        else
        {
            pieChart.setNoDataText("No Records for this month");
            pieChart.setNoDataTextColor(Color.BLACK);
        }

    }


}
