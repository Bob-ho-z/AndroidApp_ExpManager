package edu.cuhk.csci3310.expmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class DetailRecordActivity extends AppCompatActivity {
    private Bundle detailBundle; //storing original
    private TextView mDateOfRecord;
    private TextView mName;
    private Spinner mRecord_type;
    private TextView mDescription;
    private TextView mAmount;
    private CalendarView mCalendarView;
    private Button updateButton;
    private String log = "editRecord";
    private databaseHelper dbHelper;
    private int recordID;

    private boolean isUpdated = false;
    private String recordName;
    private String recordDetail;
    private int recordType;
    private double recordAmount;
    private String recordDate;

    private double originAmount;
    private String mSharedPrefFile = "edu.cuhk.csci3310.expmanager";
    SharedPreferences mPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_detail);
        Intent detailIntent = getIntent();
        detailBundle = detailIntent.getExtras();
        dbHelper = new databaseHelper(this);

        //binding, putting information to the TextView
        bindDetailView();
        setDetailContent();

        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                String curDate = String.valueOf(year) + "-" + checkDateFormat(month+1) + "-" +
                        checkDateFormat(dayOfMonth);
                mDateOfRecord.setText(curDate);
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int flag = checkUpdateDetail();
                if (flag == -2){
                    Toast.makeText(DetailRecordActivity.this,
                            "The record are same to the previous one!",Toast.LENGTH_SHORT).show();
                }
                else if (flag == -1){
                    Toast.makeText(DetailRecordActivity.this,
                            "The field cannot be empty!",Toast.LENGTH_SHORT).show();
                }
                else{
                    updateRecord();
                    isUpdated = true;
                    Toast.makeText(DetailRecordActivity.this,"Updated!",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    //binding
    private void bindDetailView(){
        mCalendarView = (CalendarView) findViewById(R.id.calendar_input);
        mDateOfRecord = (TextView) findViewById(R.id.date);
        mName = (TextView) findViewById(R.id.record_name);
        mRecord_type = (Spinner) findViewById(R.id.spinner_record_type);
        mDescription = (TextView) findViewById(R.id.description);
        mAmount = (TextView) findViewById(R.id.amount);
        updateButton = (Button) findViewById(R.id.button_updateRecord);
    }

    //put detail to the table
    private void setDetailContent(){
        recordID = detailBundle.getInt("id");
        mName.setText(detailBundle.getString("name","NULL"));
        mDescription.setText(detailBundle.getString("description","NULL"));
        mAmount.setText(Double.toString(detailBundle.getDouble("amount",0)));
        originAmount = detailBundle.getDouble("amount",0);
        mDateOfRecord.setText(detailBundle.getString("date","2000-01-01"));
        mRecord_type.setSelection(detailBundle.getInt("type",0));
    }

    //check whether the input is edited
    private int checkUpdateDetail(){
        if(!isUpdated){
            recordName = detailBundle.getString("name","NULL");
            recordDetail = detailBundle.getString("description","NULL");
            recordDate = detailBundle.getString("date","2000-01-01");
            recordAmount = detailBundle.getDouble("amount",0);
            recordType = detailBundle.getInt("type",0);
        }

        String newRecordName = mName.getText().toString();
        String newRecordDetail = mDescription.getText().toString();
        String newRecordDate = mDateOfRecord.getText().toString();
        int newRecordType = mRecord_type.getSelectedItemPosition();
        String newRecordAmount = mAmount.getText().toString();

        if(newRecordName.isEmpty() || newRecordDetail.isEmpty() ||
                newRecordDate.isEmpty() || newRecordAmount.isEmpty() || newRecordDate.isEmpty()) {
            return -1;
        }
        else if(Double.parseDouble(newRecordAmount) != recordAmount ||
                !recordName.equals(newRecordName) ||
                !recordDetail.equals(newRecordDetail) ||
                newRecordType != recordType ||
                !recordDate.equals(newRecordDate)){
            recordName = newRecordName;
            recordDetail = newRecordDetail;
            recordDate = newRecordDate;
            recordType = newRecordType;
            recordAmount = Double.parseDouble(newRecordAmount);
            return 0;
        }
        else return -2;
    }

    protected String checkDateFormat(int val){
        if (val < 10)
            return "0" + String.valueOf(val);
        return String.valueOf(val);
    }


    //save to the database
    protected void updateRecord(){
        String newRecordName = mName.getText().toString();
        String newRecordDetail = mDescription.getText().toString();
        String newRecordDate = mDateOfRecord.getText().toString();
        int newRecordType = mRecord_type.getSelectedItemPosition();
        String newRecordAmount = mAmount.getText().toString();

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        //data will be updated
        ContentValues values = new ContentValues();
        values.put("title", newRecordName);
        values.put("description", newRecordDetail);
        values.put("type", newRecordType);
        values.put("amount", Double.parseDouble(newRecordAmount));
        values.put("date", newRecordDate);
        //where clauses
        String where = "id=?";
        String[] whereArgs = new String[] {String.valueOf(recordID)};
        db.update("sampleRecord0",values,where,whereArgs);

        // Notification
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);
        float totalExpense = mPreferences.getFloat("totalExpense",900f) - (float) originAmount + Float.parseFloat(newRecordAmount);
        float expenseLimit = mPreferences.getFloat("budget",900f);
        boolean notificationSwitch = mPreferences.getBoolean("switchIsChecked",false);
        if(totalExpense>=expenseLimit && notificationSwitch)
        {
            Intent notificationIntent = new Intent(this, DetailRecordActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(this,
                    3, notificationIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);
            NotificationManager nm = (NotificationManager) this
                    .getSystemService(Context.NOTIFICATION_SERVICE);
            Resources res = this.getResources();
            Notification.Builder builder = new Notification.Builder(this);
            builder.setContentIntent(contentIntent)
                    .setSmallIcon(R.drawable.ic_type_income)
                    .setWhen(System.currentTimeMillis())
                    .setAutoCancel(true)
                    .setContentTitle("NOTICE!")
                    .setContentText("Your total Expense already larger than limit!");
            NotificationChannel channel = new NotificationChannel(
                    "4",
                    "Notification Channel for Max Expense",
                    NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(channel);
            builder.setChannelId("1");
            Notification n = builder.build();
            nm.notify(5, n);
        }
        // Notification End

    }

    @Override
    public void onBackPressed(){
        //check if it is the first time the users use
        //go back to the first stage (new PIN code) if curStage is 2
        Intent resultIntent = new Intent();
        if(isUpdated){
            Bundle updateBundle = new Bundle();
            updateBundle.putInt("id",recordID);
            updateBundle.putString("name",recordName);
            updateBundle.putString("description",recordDetail);
            updateBundle.putString("date",recordDate);
            updateBundle.putInt("type",recordType);
            updateBundle.putDouble("amount",recordAmount);
            resultIntent.putExtras(updateBundle);
            setResult(1, resultIntent);
            finish();
        }
        // if not updated
        setResult(2,resultIntent);
        finish();
    }

}