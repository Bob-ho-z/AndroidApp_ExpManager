package edu.cuhk.csci3310.expmanager;

public interface onUpdateSummary {
    public void updateSummary();



}
