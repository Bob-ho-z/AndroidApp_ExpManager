package edu.cuhk.csci3310.expmanager;

public class Record {
    //constructor
    private int id;
    private String name;
    private int category; //0-->x, 1-->y, 2-->z, 3-->a, 4-->b, 5-->others
    private String description;
    private double amount;
    private String date_of_record;

    public Record(int id, String name, String description, int category, double amount, String date_of_record) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.description = description;
        this.amount = amount;
        this.date_of_record = date_of_record;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDate_of_record() {
        return date_of_record;
    }

    public void setDate_of_record(String date_of_record) {
        this.date_of_record = date_of_record;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
