package edu.cuhk.csci3310.expmanager;

import static java.lang.String.valueOf;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class AddRecordActivity extends AppCompatActivity {

    private String record_name;
    private String record_description;
    private int record_type_id;
    private double record_amount;
    private TextView mDateOfRecord;
    private TextView mName;
    private Spinner mRecord_type;
    private TextView mDescription;
    private TextView mAmount;
    private CalendarView mCalendarView;
    private String log = "addRecord";
    private databaseHelper dbHelper;

    private String mSharedPrefFile = "edu.cuhk.csci3310.expmanager";
    SharedPreferences mPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record);
        dbHelper = new databaseHelper(this);

        //binding
        mCalendarView = (CalendarView) findViewById(R.id.calendar_input);
        mDateOfRecord = (TextView) findViewById(R.id.date);
        mName = (TextView) findViewById(R.id.record_name);
        mRecord_type = (Spinner) findViewById(R.id.spinner_record_type);
        mDescription = (TextView) findViewById(R.id.description);
        mAmount = (TextView) findViewById(R.id.amount);

        //setting event listener
        Button cancelButton = (Button) findViewById(R.id.button_cancel);
        Button submitButton = (Button) findViewById(R.id.button_updateRecord);

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //add record
                if(checkInput()==-1){
                    Toast.makeText(AddRecordActivity.this, "The inputs cannot be empty!", Toast.LENGTH_SHORT).show();
                }
                else{

                    Intent resultIntent = new Intent();
                    setResult(1, resultIntent);
                    finish();
                };
            }
        });


        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                String curDate = valueOf(year) + "-" + checkDateFormat(month+1) + "-" +
                        checkDateFormat(dayOfMonth);
                mDateOfRecord.setText(curDate);
            }
        });


    }

    protected String checkDateFormat(int val){
        if (val < 10)
            return "0" + valueOf(val);
        return valueOf(val);
    }

    protected int checkInput(){
        String name = mName.getText().toString();
        String amount = mAmount.getText().toString();
        String description = mDescription.getText().toString();
        String _date = mDateOfRecord.getText().toString();
        int RecordTypeID = getTypeId();

        //Log.d("addRecord",Integer.toString(RecordTypeID));
        if(name.isEmpty()|| amount.isEmpty() || description.isEmpty() || _date.isEmpty() || RecordTypeID < 0)
            return -1;
        //add to the recordTable
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        dbHelper.onCreate(db); //for adding table
        ContentValues values = new ContentValues();
        values.put("title", name);
        values.put("description", description);
        values.put("type", RecordTypeID);
        values.put("amount", Double.parseDouble(amount));
        values.put("date", (String) mDateOfRecord.getText());
        db.insert("sampleRecord0", null, values);

        // Notification
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);
        float totalExpense = mPreferences.getFloat("totalExpense",900f) + Float.parseFloat(amount);
        float expenseLimit = mPreferences.getFloat("budget",900f);
        boolean notificationSwitch = mPreferences.getBoolean("switchIsChecked",false);
        if(totalExpense>=expenseLimit && notificationSwitch)
        {
            Intent notificationIntent = new Intent(this, AddRecordActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(this,
                    0, notificationIntent,
                    PendingIntent.FLAG_CANCEL_CURRENT);
            NotificationManager nm = (NotificationManager) this
                    .getSystemService(Context.NOTIFICATION_SERVICE);
            Resources res = this.getResources();
            Notification.Builder builder = new Notification.Builder(this);
           builder.setContentIntent(contentIntent)
                    .setSmallIcon(R.drawable.ic_type_income)
                    .setWhen(System.currentTimeMillis())
                    .setAutoCancel(true)
                    .setContentTitle("NOTICE!")
                    .setContentText("Your total Expense already larger than limit!");
            NotificationChannel channel = new NotificationChannel(
                    "1",
                    "Notification Channel for Max Expense",
                    NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(channel);
            builder.setChannelId("1");
            Notification n = builder.build();
            nm.notify(2, n);
        }
        // Notification End


        return 1;
    }

    protected int getTypeId(){
        String type_of_record = (String) mRecord_type.getSelectedItem();
        if (type_of_record.equals("income"))
            return 0;
        else if (type_of_record.equals("diet"))
            return 1;
        else if (type_of_record.equals("tuition fees"))
            return 2;
        else if (type_of_record.equals("leisure"))
            return 3;
        else if (type_of_record.equals("others"))
            return 4;
        return -1;

    }
}