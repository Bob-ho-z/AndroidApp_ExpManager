package edu.cuhk.csci3310.expmanager;

import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class ViewSummary extends AppCompatActivity {

    private databaseHelper dbHelper; // for handling data
    ArrayList<HashMap<String, String>> lastMonthDataArrayList = new ArrayList<>();//get last month data
    ArrayList<HashMap<String, String>> thisMonthDataArrayList = new ArrayList<>();//get this month data
    private  boolean notEnd = true;
    private LineChart lineChart;
    public static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    public static final SimpleDateFormat checkMonth = new SimpleDateFormat("M");
    public static final SimpleDateFormat checkDay = new SimpleDateFormat("dd");
    private int DBMonthI, currentMonthI, DBDayI;
    private String DBMonths, DBDays;
    private Cursor c;
    //private List<String> xAxisValues = new ArrayList<>(Arrays.asList("Day 1", "Day 7", "Day 14", "Day 21", "Day 28"));
    final String[] dayXAxis  = new String[] { "Day 1","Day 2","Day 3","Day 4","Day 5","Day 6","Day 7", "Day 8","Day 9","Day 10","Day 11","Day 12","Day 13","Day 14", "Day 15", "Day 16","Day 17","Day 18","Day 19","Day 20","Day 21", "Day 22","Day 23","Day 24","Day 25","Day 26","Day 27","Day 28","Day 29","Day 30"};
    protected void onCreate(Bundle savedInstanceState) {
        //Log.d("debug","enter to view summary page");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_summary);
        dbHelper = new databaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Date d = new Date(System.currentTimeMillis());
        String currentMonthS = checkMonth.format(d);
       // Log.d("debug","currentMonth is "+ currentMonthS);
        try
        {
            currentMonthI = Integer.parseInt(currentMonthS);

        }
        catch (NumberFormatException e)
        {
            e.printStackTrace();
           // Log.d("debug","current date cannot prase");
        }




        c = db.query("sampleRecord0", new String[]{"id",  "amount","date"}, "type != 0", null, null, null, "date");
        if (c.getCount() > 0) {
            c.moveToFirst();
            //Log.d("debug","go into first if");

            //ArrayList<HashMap<String, String>> selectedDataArrayList = new ArrayList<>();
            while (notEnd) {
                HashMap<String, String> hashMap = new HashMap<>();

                String id = c.getString(0);
                String amount = c.getString(1);
                String date = c.getString(2);
                // Log.d("debug","Date is "+ date);

                hashMap.put("id", id);
                hashMap.put("amount", amount);
                hashMap.put("date", date);
                try {
                    //  Log.d("debug","Date in try is "+ date);
                    DBMonths = date.substring(5,7);
                    //  Log.d("debug","DBMonths is "+ DBMonths);
                    DBMonthI = Integer.parseInt(DBMonths);
                    // Log.d("debug","dbmonth is "+ DBMonthI + "and currentMonthI is "+ currentMonthI);
                }
                catch (NumberFormatException e)
                {
                    e.printStackTrace();
                    //  Log.d("debug","db date cannot parse to int");
                }


                if(DBMonthI == currentMonthI)
                    thisMonthDataArrayList.add(hashMap);
                else if(DBMonthI == currentMonthI - 1)
                    lastMonthDataArrayList.add(hashMap);
                if(!(c.moveToNext()))
                {
                    notEnd = false;
                }

            }

            if(thisMonthDataArrayList.isEmpty() && lastMonthDataArrayList.isEmpty())
            {
                lineChart = findViewById(R.id.summary_line_chart);
                lineChart.setNoDataText("No Records for this month and last month");
                lineChart.setNoDataTextColor(Color.BLACK);
                return;
            }

            lineChart = findViewById(R.id.summary_line_chart);
            configureLineChart();

        }
        else
        {
            //thisMonthDataArrayList.clear();
            //lastMonthDataArrayList.clear();
            lineChart = findViewById(R.id.summary_line_chart);
            lineChart.setNoDataText("No Records for this month and last month");
            lineChart.setNoDataTextColor(Color.BLACK);
            //configureLineChart();

        }





    }

    private void configureLineChart()
    {
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        List<Entry> expenseEntries = getThisMonthExpenseEntries();
        List<Entry> lastMonthexpenseEntries = getLastMonthExpenseEntries();
        LineDataSet set1, set2;
        set1 = new LineDataSet(expenseEntries, "This month");
        set1.setColor(Color.BLUE);
        set1.setValueTextColor(Color.BLUE);
        set1.setValueTextSize(10f);
        set1.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        dataSets.add(set1);

        set2 = new LineDataSet(lastMonthexpenseEntries, "Last month");
        set2.setColor(Color.RED);
        set2.setValueTextColor(Color.RED);
        set2.setValueTextSize(10f);
        set2.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        dataSets.add(set2);

        //to hide background lines
        lineChart.getXAxis().setDrawGridLines(false);
        lineChart.getAxisLeft().setDrawGridLines(false);
        lineChart.getAxisRight().setDrawGridLines(false);

        //to hide right Y and top X border
        YAxis rightYAxis = lineChart.getAxisRight();
        rightYAxis.setEnabled(false);
        XAxis topXAxis = lineChart.getXAxis();
        topXAxis.setEnabled(false);

        YAxis leftYAxis = lineChart.getAxisLeft();
        leftYAxis.setEnabled(true);
        leftYAxis.setDrawGridLines(false);
        leftYAxis.setAxisMinimum(0);

        //setPosition(YAxisLabelPosition pos): Sets the position where the axis-labels should be drawn. Either INSIDE_CHART or OUTSIDE_CHART.
        //ArrayList<ILineDataSet> timeDatasets = new ArrayList<>();
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setAxisMinimum(0f);
        xAxis.setAxisMaximum(30f);
        xAxis.setCenterAxisLabels(true);
        xAxis.setSpaceMax(2f);
        xAxis.setEnabled(true);
        xAxis.setDrawGridLines(false);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        set1.setLineWidth(4f);
        set1.setCircleRadius(3f);
        set1.setDrawValues(false);


        ValueFormatter formatter = new ValueFormatter() {
            @Override
            public String getAxisLabel(float value, AxisBase axis) {
                //Log.d("debug","value is "+ value);
                if (value >= 0) {
                    if (dayXAxis.length > (int) value) {
                        return dayXAxis[(int) value];
                    } else return "";
                } else {
                    return "";
                }
            }
        };

        lineChart.getXAxis().setValueFormatter(formatter);
        LineData data = new LineData(dataSets);
        lineChart.setData(data);
        lineChart.animateX(1000);
        lineChart.invalidate();

    }

    private List<Entry> getThisMonthExpenseEntries() {
        ArrayList<Entry> expenseEntries = new ArrayList<>();
        int dataLength = thisMonthDataArrayList.size();
       // Log.d("debug","This month data size is " + thisMonthDataArrayList.size());
        float expense = 0;
        for(int i=0;i<dataLength;i++)
        {

            expense = expense  + Float.parseFloat(thisMonthDataArrayList.get(i).get("amount"));
          //  Log.d("debug","day string is " +thisMonthDataArrayList.get(i).get("date"));
            DBDays = thisMonthDataArrayList.get(i).get("date").substring(8);
            float xscale = Float.parseFloat(DBDays);
           // Log.d("debug","for "+ i + "xscale is "+ xscale + " expense is "+ expense);
            expenseEntries.add(new Entry(xscale, expense));
           // Log.d("debug"," ie day of "+ i + "is " + expenseEntries.get(i));
        }
        return expenseEntries.subList(0, dataLength);
    }

    private List<Entry> getLastMonthExpenseEntries() {
        ArrayList<Entry> expenseEntries = new ArrayList<>();
        int dataLength = lastMonthDataArrayList.size();
       // Log.d("debug","This month data size is " + lastMonthDataArrayList.size());
        float expense = 0;
        for(int i=0;i<dataLength;i++)
        {

            expense = expense  + Float.parseFloat(lastMonthDataArrayList.get(i).get("amount"));
          //  Log.d("debug","day string is " +lastMonthDataArrayList.get(i).get("date"));
            DBDays = lastMonthDataArrayList.get(i).get("date").substring(8);
           // Log.d("debug","DBDays at last month is " + DBDays);
            float xscale = Float.parseFloat(DBDays);
           // Log.d("debug","last month for "+ i + "xscale is "+ xscale + " expense is "+ expense);
            expenseEntries.add(new Entry(xscale, expense));
           // Log.d("debug"," ie day of "+ i + "is " + expenseEntries.get(i));
        }
        return expenseEntries.subList(0, dataLength);
    }

}

