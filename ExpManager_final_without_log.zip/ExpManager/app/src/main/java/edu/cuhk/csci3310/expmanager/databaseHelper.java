package edu.cuhk.csci3310.expmanager;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class databaseHelper extends SQLiteOpenHelper {
    private final static int DBversion = 2;
    private final static String databaseName = "sampleRecord.db";
    private final static String tableName = "sampleRecord0";
    private final static String log = "db";


    public databaseHelper(Context context) {
        super(context, databaseName, null, DBversion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String sql = "CREATE TABLE IF NOT EXISTS " + tableName + "( " +
                " id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                " title VARCHAR(50)," +
                " description VARCHAR(255)," +
                " type INTEGER," +
                " amount REAL," +
                " date TEXT" + ");";
        db.execSQL(sql);
        //Log.d(log,"createDB");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldv, int newv) {
        final String SQL = "DROP TABLE " + tableName;
        db.execSQL(SQL);
        //Log.d(log,"delDB");
    }
}
