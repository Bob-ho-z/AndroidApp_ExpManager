package edu.cuhk.csci3310.expmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class SetPINActivity extends AppCompatActivity {
    private int flag = 1; // 1 for enterPIN, 2 for confirm PIN (initial)/PIN for reset, 3 for confirm PIN (reset)
    private String setType; //setPIN, resetPIN, enterPIN
    private String MsgPINCode = ""; //display in the mobile
    private String curPINCode = ""; //for holding the PIN
    private String newPINCode = ""; //to check if new == cur (on setting/resetting PIN)
    private String storedPINCode = ""; //the pin code inside sharedpreference

    private TextView mShowPINCode;
    private TextView mHeaderView;
    private TextView mErrorMsgView;

    private String mSharedPrefFile = "edu.cuhk.csci3310.expmanager";
    SharedPreferences mPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_pin_code);
        mShowPINCode = (TextView) findViewById(R.id.password);
        mHeaderView = (TextView) findViewById(R.id.title);
        mErrorMsgView = (TextView) findViewById(R.id.errorMessage);
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);

        Intent intent = getIntent(); // to get the flag type "set/reset the password"
        setType = intent.getStringExtra("setType");
        setHeaderText();
        getPIN();

        Button delButton = (Button) findViewById(R.id.button_del);
        delButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delNumber();
            }
        });

        Button subButton = (Button) findViewById(R.id.button_submit);
        subButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //depends on the enter/set/reset ** setting below
                if(setType.equals("setPIN"))
                    submitPIN();
                else if(setType.equals("enterPIN")){
                    if(verifyPIN() == 1)
                        finish();
                }
                else{
                    if(flag == 1){
                        if(verifyPIN() == 1){
                            mHeaderView.setText("Enter Your new PIN Code");
                            mShowPINCode.setText("");
                            curPINCode = "";
                            flag = 2;
                        }
                    }
                    else
                        resetPIN();
                }
            }
        });
    }

    //add a number to a PIN Code
    public void addNumber(View view) {
        Button numberButton = (Button) view;
        String tmp_PinCode = "";
        if (curPINCode.length() < 8){
            String number = numberButton.getText().toString();
            curPINCode = curPINCode + number;
            for(int n = 0; n < curPINCode.length() - 1; n++)
                tmp_PinCode = tmp_PinCode + "*";
            mShowPINCode.setText(tmp_PinCode + number);
        }
    }

    //delete a number of a PIN Code
    private void delNumber(){
        String tmp_PinCode = "";
        if (curPINCode.length() > 0){
            curPINCode = curPINCode.substring(0,curPINCode.length()-1);
            for(int n = 0; n < curPINCode.length() - 1; n++)
                tmp_PinCode = tmp_PinCode + "*";
            if(curPINCode.length() >= 1)
                tmp_PinCode = tmp_PinCode + curPINCode.charAt(curPINCode.length()-1);
            mShowPINCode.setText(tmp_PinCode);
        }
    }

    //get the original PINcode
    private void getPIN(){
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);
        storedPINCode = mPreferences.getString("PINCode","null");
    }

    //submit the PIN code for setting PIN
    private void submitPIN(){
        if(flag == 1) {
            if (curPINCode.length() < 4) {
                mErrorMsgView.setText("Length of PIN code should be at least 4");
            } else {
                mHeaderView.setText("Confirm your PIN Code");
                flag = 2;
                newPINCode = curPINCode;
                curPINCode = "";
                mShowPINCode.setText("");
            }
        }
        else{
            String tmp_toast_msg = "";
            if(curPINCode.length() < 0){
                mErrorMsgView.setText("Length of PIN code should be at least 4");
                curPINCode = "";
                mShowPINCode.setText("");
            }
            else if (!curPINCode.equals(newPINCode)){
                mErrorMsgView.setText("The PIN code are not same to the previous one...");
                curPINCode = "";
                mShowPINCode.setText("");
            }
            else{
                //storing the passcode (encrypted) to the sharedpref.
                //enter to the mainActivity
                mPreferences.edit().putString("PINCode",newPINCode).apply();
                finish();
            }
        }

    }

    //to check whether the PIN code is valid --> if valid --> can enter MainActivity (enter)
    private int verifyPIN() {
        if (curPINCode.length() >= 4){
            //redirect // enter to SetPINActivity
            if(curPINCode.equals(storedPINCode)) {
                return 1;
            }
            else{
                mErrorMsgView.setText("Invalid PINCode");
                curPINCode = "";
                mShowPINCode.setText("");
                return -1;
            }
        }
        else if(curPINCode.length() > 0){
            //add message to the warning bar
            mErrorMsgView.setText("Length of your PIN code should be at least 4");
            mShowPINCode.setText("");
            curPINCode = "";
            return -1;
        }
        else{
            mErrorMsgView.setText("PIN code cannot be empty");
            return -1;
        }
    }

    //submit the PIN code for resetting PIN
    private void resetPIN(){
        if (flag == 2)
            if (curPINCode.equals(storedPINCode)){
                mErrorMsgView.setText("It is same to the previous PIN Code!");
            }
            else if (curPINCode.length() < 4){
                //add message to the warning bar
                mErrorMsgView.setText("Length of PIN code should be at least 4");
                curPINCode = "";
                mShowPINCode.setText("");
            }
            else{
                newPINCode = curPINCode;
                flag = 3;
                mHeaderView.setText("Confirm your new PIN code");
                mErrorMsgView.setText("");
                curPINCode = "";
                mShowPINCode.setText("");
            }
        else{
            if(curPINCode.equals(newPINCode)){
                //store the PINcode
                mPreferences.edit().putString("PINCode",newPINCode).apply();
                //send resultIntent to the MainActivity
                Intent resultIntent = new Intent();
                setResult(1,resultIntent);
                finish();
            }
            else if (curPINCode.length() < 4){
                //add message to the warning bar
                mErrorMsgView.setText("Length of PIN code should be at least 4");
            }
            else{
                mErrorMsgView.setText("It is different to the previous PIN Code!");
                curPINCode = "";
                mShowPINCode.setText("");
            }

        }

    }

    //header Text
    private void setHeaderText(){
        if(setType.equals("setPIN")){
            mHeaderView.setText("Set your PIN Code");
        }
        else if(setType.equals("enterPIN")){
            mHeaderView.setText("Enter Your PIN Code");
        }
        else{
            mHeaderView.setText("Enter your PIN Code");
        }
    }

    //blocking for setting/entering, non-blocking for reseting PIN code
    @Override
    public void onBackPressed(){
        //check if it is the first time the users use
        //go back to the first stage (new PIN code) if curStage is 2
        if(setType.equals("setPIN")){
            if (flag >= 2){
                flag = 1;
                mHeaderView.setText("Set your PIN Code");
            }
            mHeaderView.setText("Set your PIN Code");
            //just act as a block
            //to set the PIN code
        }
        else if(setType.equals("enterPIN")){
            //block
            //finish();
        }
        else{
            if(flag > 2){
                flag = 2;
                mHeaderView.setText("Enter Your new PIN Code");
            }
            else finish(); //go back to MainActivity
        }

    }

}