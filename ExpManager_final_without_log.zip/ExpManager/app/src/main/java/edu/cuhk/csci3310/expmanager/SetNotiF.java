package edu.cuhk.csci3310.expmanager;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class SetNotiF extends AppCompatActivity {
    private String mSharedPrefFile = "edu.cuhk.csci3310.expmanager";
    SharedPreferences mPreferences;
    SharedPreferences.Editor preferencesEditor;
    private Switch notifSwitch;
    private boolean switchIsChecked;
    private  boolean notEnd = true;
    private databaseHelper dbHelper;
    public static final SimpleDateFormat checkMonth = new SimpleDateFormat("M");
    private int currentMonthI, DBMonthI,DBDayI;
    private  float AmountF;
    private float Day10Amount=0f, Day20Amount=0f, Day30Amount=0f;
    private TextView budget;
    private EditText newBudget;
    private  float budgetAmount;
    ArrayList<HashMap<String, String>> thisMonthDataArrayList = new ArrayList<>();//get this month data
    private String DBMonths, DBDayS, AmountS;
    private BarChart barChart;
    private Button setButton;
    final String[] dayXAxis  = new String[] { "Before Day 10","Before Day 20","Before Day 30"};
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_notif);
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);
        preferencesEditor = mPreferences.edit();
        //Log.d("debug","enter to setnotif");

        switchIsChecked = mPreferences.getBoolean("switchIsChecked",false);
        notifSwitch = (Switch) findViewById(R.id.notif);
        notifSwitch.setChecked(switchIsChecked);
        notifSwitch.setOnCheckedChangeListener(
                new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                        if(isChecked)
                        {
                            switchIsChecked = true;
                            preferencesEditor.putBoolean("switchIsChecked",true);
                            preferencesEditor.apply();
                            //Log.d("debug","switch is check");
                        }
                        else
                        {
                            switchIsChecked = false;
                            preferencesEditor.putBoolean("switchIsChecked",false);
                            preferencesEditor.apply();
                            //Log.d("debug","switch is not check");
                        }
                    }
                }

        );


        barChart = (BarChart) findViewById(R.id.notif_barchart);
        showBarChart();
        budget = (TextView) findViewById(R.id.budget);
        budgetAmount = mPreferences.getFloat("budget",900f);
        budget.setText("HK$" + Float.toString(budgetAmount));
        LimitLine ll = new LimitLine(budgetAmount);
        ll.setLineColor(Color.RED);
        barChart.getAxisLeft().addLimitLine(ll);

        setButton = (Button) findViewById(R.id.budget_set_button);
        setButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                newBudget = (EditText) findViewById(R.id.new_budget);
                //Log.d("debug","new budget is "+ newBudget.getText().toString());
                preferencesEditor.putFloat("budget",Float.parseFloat(newBudget.getText().toString()));
                preferencesEditor.apply();
                budgetAmount = mPreferences.getFloat("budget",900f);
                budget.setText("HK$" + Float.toString(budgetAmount));
                barChart.getAxisLeft().removeLimitLine(ll);
                LimitLine ll = new LimitLine(budgetAmount);
                ll.setLineColor(Color.RED);
                barChart.getAxisLeft().addLimitLine(ll);
            }
        });





    }

    private void showBarChart()
    {
        barChart.setDrawGridBackground(false);
        barChart.setDrawBarShadow(false);
        barChart.setHighlightFullBarEnabled(false);
        barChart.setDrawBorders(false);
        Description description = new Description();
        description.setEnabled(false);
        barChart.setDescription(description);

        YAxis rightYAxis = barChart.getAxisRight();
        rightYAxis.setEnabled(false);
        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextSize(12f);
        xAxis.setAxisMinimum(0f);
        //xAxis.setAxisMaximum(3f);
        xAxis.setGranularity(1f);
        xAxis.setCenterAxisLabels(true);
        xAxis.setEnabled(true);
        xAxis.setSpaceMax(0.5f);
        xAxis.setSpaceMin(0.5f);
        xAxis.setDrawGridLines(false);

        ValueFormatter formatter = new ValueFormatter() {
            @Override
            public String getAxisLabel(float value, AxisBase axis) {
                //Log.d("debug","value is "+ value);
                if (value >= 0) {
                    if (dayXAxis.length > (int) value) {
                        return dayXAxis[(int) value];
                    } else return "";
                } else {
                    return "";
                }
            }
        };

        barChart.getXAxis().setValueFormatter(formatter);

        YAxis yAxis = barChart.getAxisLeft();
        yAxis.setAxisMinimum(0f);
        yAxis.setDrawGridLines(false);

        //List<BarChart> entries = new ArrayList<>();


        dbHelper = new databaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Date d = new Date(System.currentTimeMillis());
        String currentMonthS = checkMonth.format(d);
        try
        {
            currentMonthI = Integer.parseInt(currentMonthS);

        }
        catch (NumberFormatException e)
        {
            e.printStackTrace();
            //Log.d("debug","current date cannot prase");
        }

        Cursor c = db.query("sampleRecord0", new String[]{"id", "type", "amount","date"}, "type != 0", null, null, null, "date");
        if (c.getCount() > 0) {
            c.moveToFirst();


            while (notEnd) {
                HashMap<String, String> hashMap = new HashMap<>();

                String id = c.getString(0);
                String type = c.getString(1);
                String amount = c.getString(2);
                String date = c.getString(3);
                // Log.d("debug","Date is "+ date);

                hashMap.put("id", id);
                hashMap.put("type",type);
                hashMap.put("amount", amount);
                hashMap.put("date", date);
                try {
                    //  Log.d("debug","Date in try is "+ date);
                    DBMonths = date.substring(5,7);
                    //  Log.d("debug","DBMonths is "+ DBMonths);
                    DBMonthI = Integer.parseInt(DBMonths);
                    // Log.d("debug","dbmonth is "+ DBMonthI + "and currentMonthI is "+ currentMonthI);
                }
                catch (NumberFormatException e)
                {
                    e.printStackTrace();
                    //  Log.d("debug","db date cannot parse to int");
                }


                if(DBMonthI == currentMonthI)
                    thisMonthDataArrayList.add(hashMap);
                if(!(c.moveToNext()))
                {
                    notEnd = false;
                }

            }

            if(thisMonthDataArrayList.isEmpty())
            {
                barChart.setNoDataText("No Records for this month");
                barChart.setNoDataTextColor(Color.BLACK);
                return;
            }


            // amount data.
            for(int i=0;i<thisMonthDataArrayList.size();i++)
            {
                DBDayS = thisMonthDataArrayList.get(i).get("date").substring(8);
                DBDayI = Integer.parseInt(DBDayS);
                AmountS = thisMonthDataArrayList.get(i).get("amount");
                AmountF = Float.parseFloat(AmountS);
                if(DBDayI>0 && DBDayI<=10)
                {
                    Day10Amount = Day10Amount + AmountF;
                    Day20Amount = Day20Amount + AmountF;
                    Day30Amount = Day30Amount + AmountF;

                }
                else if(DBDayI>10 && DBDayI<=20)
                {
                    Day20Amount = Day20Amount + AmountF;
                    Day30Amount = Day30Amount + AmountF;
                }
                else if(DBDayI>20 && DBDayI<=31)
                {
                    Day30Amount = Day30Amount + AmountF;
                }
            }

            List<BarEntry>  entries = new ArrayList<>();
            entries.add(new BarEntry(0.5f,Day10Amount));
            entries.add(new BarEntry(1.5f,Day20Amount));
            entries.add(new BarEntry(2.5f,Day30Amount));

            BarDataSet set = new BarDataSet(entries,"This Month Records");
            BarData data = new BarData(set);
            data.setBarWidth(0.4f);
            barChart.setData(data);
            barChart.setFitBars(true);

            barChart.invalidate();




        }
        else
        {
            barChart.setNoDataText("No Records for this month");
            barChart.setNoDataTextColor(Color.BLACK);
        }










    }
}
