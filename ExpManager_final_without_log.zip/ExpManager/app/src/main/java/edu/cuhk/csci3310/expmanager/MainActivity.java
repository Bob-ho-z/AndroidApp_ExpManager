package edu.cuhk.csci3310.expmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

public class MainActivity extends AppCompatActivity implements onUpdateSummary{

    private String mSharedPrefFile = "edu.cuhk.csci3310.expmanager";
    private final String tag = "mainActivity";
    private Context context;
    private databaseHelper dbHelper; // for handling data
    FloatingActionButton fab; //for add record

    SharedPreferences mPreferences;

    private RecyclerView mRecyclerView;
    private RecordListAdapter mAdapter;
    private LinkedList<Record> mRecordList = new LinkedList<>();

    private TextView mTotalExpense;
    private TextView mNetGain;

    private final int REQUEST_ADD_RECORD = 1;
    private final int REQUEST_UPDATE_RECORD = 2;
    private static final int REQUEST_UPDATE_PIN = 3;

    private SharedPreferences.Editor preferencesEditor;

    public static final SimpleDateFormat checkMonth = new SimpleDateFormat("M");
    private String DBMonths;
    private int DBMonthI;
    private int currentMonthI;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //move to the SetPINCode
        if(SetPINCode()){
            //move to the login/check pin code part
            checkPINCode();
        }
        super.onCreate(savedInstanceState);
        openDB();
        //binding
        setContentView(R.layout.activity_main);
        mTotalExpense = (TextView) findViewById(R.id.totalExpense);
        mNetGain = (TextView) findViewById(R.id.netGain);
        setAddButton();
        //initialize, show all the record
        getRecord();
        mRecyclerView = (RecyclerView) findViewById(R.id.RecycleView);
        mAdapter = new RecordListAdapter(MainActivity.this, mRecordList,this);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.addItemDecoration((new DividerItemDecoration(mRecyclerView.getContext(), DividerItemDecoration.VERTICAL)));
        updateSummary();

    }


    //for the option menu bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem item = menu.findItem(R.id.menu_search);
        SearchView searchView = (SearchView) item.getActionView();
        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                mAdapter.getFilter().filter(s);
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case (R.id.menu_view_summary):
                //Toast.makeText(MainActivity.this,"faf",Toast.LENGTH_SHORT).show();
                //break;
                Intent intent = new Intent(this, ViewSummary.class);
                this.startActivity(intent);
                break;
            case (R.id.menu_analyse_expenses):
                Intent intent_analyse = new Intent(this,AnalyseExpenses.class);
                this.startActivity(intent_analyse);
                break;
            case (R.id.menu_reset_PIN_code):
                ResetPINCode();
                break;
            case (R.id.menu_set_notif):
                //Toast.makeText(MainActivity.this,"setNotif",Toast.LENGTH_SHORT).show();
                Intent intent_notif = new Intent(this,SetNotiF.class);
                this.startActivity(intent_notif);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    //for PIN code
    private boolean SetPINCode(){
        //check if there exist PIN code in sharedpref.
        boolean isPINCodeExists = getPINCode();
        //if no --> shift to the SetPINActivity
        if(!isPINCodeExists){
            Intent intent = new Intent(this,SetPINActivity.class);
            intent.putExtra("setType","setPIN");
            this.startActivity(intent);
            return false;
        }
        return true;
    }

    private boolean getPINCode() {
        mPreferences = getSharedPreferences(mSharedPrefFile, MODE_PRIVATE);
        preferencesEditor = mPreferences.edit();
        String pinCode = mPreferences.getString("PINCode","null");
        if(pinCode.equals("null"))
            return false;
        return true;
    }

    private void checkPINCode(){
        Intent intent = new Intent(this,SetPINActivity.class);
        intent.putExtra("setType","enterPIN");
        this.startActivity(intent);
    }

    private void ResetPINCode() {
        Intent intent = new Intent(this,SetPINActivity.class);
        intent.putExtra("setType","resetPIN");
        this.startActivity(intent);
    }

    //for database
    private void openDB(){
        dbHelper = new databaseHelper(this);
    }

    //add record to the database
    private void setAddButton(){
        fab  = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //add record
                //addRecord();
                //debuging..
                //checkRecord();
                Intent intent = new Intent(MainActivity.this,AddRecordActivity.class);
                startActivityForResult(intent,REQUEST_ADD_RECORD);
            }
        });

    }


    //to get all the record from the db
    private void getRecord() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String sql = "SELECT * FROM sampleRecord0 order by id";
        Cursor cus = db.rawQuery(sql, null);
        //loop until reaching the end of row
        if (cus.moveToFirst()) {
            do {
                int id = cus.getInt(0);
                String name = cus.getString(1);
                String description = cus.getString(2);
                int type = cus.getInt(3);
                double amount = cus.getDouble(4);
                String date = cus.getString(5);
                Record recordItem = new Record(id, name, description, type, amount, date);
                mRecordList.add(recordItem);
                //Log.d(tag,name + " " + description);
            } while (cus.moveToNext());
        }
    }

    //to add item to the list
    private void addRecordItem() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String sql = "SELECT * FROM sampleRecord0 where id in (SELECT MAX(id) from sampleRecord0);";
        Cursor cus = db.rawQuery(sql, null);
        //loop until reaching the end of row
        if (cus.moveToFirst()) {
            do {
                int id = cus.getInt(0);
                //Log.d("id :",String.valueOf(id));
                String name = cus.getString(1);
                String description = cus.getString(2);
                int type = cus.getInt(3);
                double amount = cus.getDouble(4);
                String date = cus.getString(5);
                Record recordItem = new Record(id, name, description, type, amount, date);
                mRecordList.addLast(recordItem);
                mAdapter.addFullList(recordItem);
            } while (cus.moveToNext());
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode) {
            case (REQUEST_ADD_RECORD) : {
                if (resultCode == 1) {
                    int recordListSize = mRecordList.size();
                    addRecordItem();
                    mRecyclerView.getAdapter().notifyItemChanged(recordListSize);
                    updateSummary();
                    Toast.makeText(MainActivity.this, "Added", Toast.LENGTH_SHORT).show();
                }
                break;
            }
            case (REQUEST_UPDATE_RECORD) :{
                if (resultCode == 1){
                    Bundle updateRecord = data.getExtras();
                    updateRecordList(updateRecord);
                    updateSummary();
                    //Log.d("update? ","yes");
                }
                break;
            }
            case (REQUEST_UPDATE_PIN) :{
                if (resultCode == 1){
                    Toast.makeText(MainActivity.this,"Update PIN code",Toast.LENGTH_SHORT).show();
                }
                break;
            }
        }
    }

    private void updateRecordList(Bundle updateRecord){
        //update new record
        int id = updateRecord.getInt("id");
        String name = updateRecord.getString("name");
        int type = updateRecord.getInt("type");
        String _date = updateRecord.getString("date");
        double amount = updateRecord.getDouble("amount");
        String description = updateRecord.getString("description");
        Record newRecord = new Record(id,name,description,type,amount,_date);

        //find position of the record in mRecyclerView
        int pos = 0;
        for (Record recordItem: mRecordList){
            if(id == recordItem.getId()){
                mRecordList.set(pos,newRecord);
                mAdapter.updateFullList(newRecord);
                mRecyclerView.getAdapter().notifyItemChanged(pos);
                break;
            }
            pos++;
        }
    }


    //update summary
    @Override
    public void updateSummary(){
        double totalExpense = 0;
        double netGain = 0;
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String sql = "SELECT * FROM sampleRecord0 where type != -1;";
        Cursor cus = db.rawQuery(sql, null);

        Date d = new Date(System.currentTimeMillis());
        String currentMonthS = checkMonth.format(d);
        try
        {
            currentMonthI = Integer.parseInt(currentMonthS);

        }
        catch (NumberFormatException e)
        {
            e.printStackTrace();
            //Log.d("debug","current date cannot prase");
        }

        //loop until reaching the end of row
        if (cus.moveToFirst()) {
            do {
                int id = cus.getInt(0);
                //Log.d("id :",String.valueOf(id));
                String name = cus.getString(1);
                String description = cus.getString(2);
                int type = cus.getInt(3);
                double amount = cus.getDouble(4);
                String date = cus.getString(5);
                DBMonths = date.substring(5,7);
                DBMonthI = Integer.parseInt(DBMonths);
                if(DBMonthI == currentMonthI)
                {
                    if (type == 0){
                        netGain += amount;
                    }
                    else{
                        netGain -= amount;
                        totalExpense += amount;
                    }
                }

            } while (cus.moveToNext());
        }
        updateNetGain(netGain);
        updateTotalExpense(totalExpense);

        // In order to set notification add total expense to preference
        preferencesEditor.putFloat("totalExpense",(float)totalExpense);
        preferencesEditor.apply();

    }


    private void updateNetGain(double new_netGain){
        double netGain = Math.round((new_netGain)*10)/10.0;
        if(netGain >= 0)
            mNetGain.setText("$" + netGain);
        else
            mNetGain.setText("-$" + (-1)*netGain);
    }

    private void updateTotalExpense(double new_totalExpense){
        mTotalExpense.setText("$" + Double.toString(Math.round(new_totalExpense*10)/10.0));
    }


    //*----------------------------------------------------------------*//
    //for debuging
    private void checkRecord(){
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String sql = "SELECT * FROM sampleRecord3";
        Cursor cus = db.rawQuery(sql,null);
        //loop until reaching the end of row
        if(cus.moveToFirst()){
            do{
                String a;
                a = cus.getString(1);
                //Log.d(tag,a);
                a = cus.getString(2);
                //Log.d(tag,a);
                a = Integer.toString(cus.getInt(3));
                //Log.d(tag,a);
                a = Double.toString(cus.getDouble(4));
                a = cus.getString(5);
                //Log.d(tag,a);
                //Log.d(tag,"=======================");
            }while(cus.moveToNext());

        }

    }

    // add record
    private int addRecord(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", "testing1");
        values.put("description", "content...");
        values.put("type", -1);
        values.put("amount", 0.5);
        values.put("date","2000-08-21");
        db.insert("sampleRecord0", null, values);
        return 1;
    }

}